import { InventoryItem, Supplier, Customer, Purchase, Sale, Receipt, Payment, User } from '../types';
import { INITIAL_DATA, INITIAL_SUPPLIERS, INITIAL_CUSTOMERS, INITIAL_PURCHASES, INITIAL_SALES, INITIAL_RECEIPTS, INITIAL_PAYMENTS, INITIAL_USERS } from '../constants';

/**
 * PRODUCTION NOTE:
 * In a real cPanel environment, replace the 'localStorage' logic below 
 * with fetch() calls to your PHP or Node.js backend.
 * Example: const response = await fetch('/api/items');
 */

const STORAGE_KEYS = {
  ITEMS: 'dinostock_items',
  SUPPLIERS: 'dinostock_suppliers',
  CUSTOMERS: 'dinostock_customers',
  PURCHASES: 'dinostock_purchases',
  SALES: 'dinostock_sales',
  RECEIPTS: 'dinostock_receipts',
  PAYMENTS: 'dinostock_payments',
  USERS: 'dinostock_users',
};

// Generic helper to get data with fallback to constants
const getData = <T>(key: string, fallback: T[]): T[] => {
  const saved = localStorage.getItem(key);
  if (!saved) {
    localStorage.setItem(key, JSON.stringify(fallback));
    return fallback;
  }
  return JSON.parse(saved);
};

// Generic helper to save data
const saveData = <T>(key: string, data: T[]): void => {
  localStorage.setItem(key, JSON.stringify(data));
};

export const apiService = {
  // Inventory
  getItems: async (): Promise<InventoryItem[]> => getData(STORAGE_KEYS.ITEMS, INITIAL_DATA),
  saveItems: async (items: InventoryItem[]) => saveData(STORAGE_KEYS.ITEMS, items),

  // Suppliers
  getSuppliers: async (): Promise<Supplier[]> => getData(STORAGE_KEYS.SUPPLIERS, INITIAL_SUPPLIERS),
  saveSuppliers: async (suppliers: Supplier[]) => saveData(STORAGE_KEYS.SUPPLIERS, suppliers),

  // Customers
  getCustomers: async (): Promise<Customer[]> => getData(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS),
  saveCustomers: async (customers: Customer[]) => saveData(STORAGE_KEYS.CUSTOMERS, customers),

  // Purchases
  getPurchases: async (): Promise<Purchase[]> => getData(STORAGE_KEYS.PURCHASES, INITIAL_PURCHASES),
  savePurchases: async (purchases: Purchase[]) => saveData(STORAGE_KEYS.PURCHASES, purchases),

  // Sales
  getSales: async (): Promise<Sale[]> => getData(STORAGE_KEYS.SALES, INITIAL_SALES),
  saveSales: async (sales: Sale[]) => saveData(STORAGE_KEYS.SALES, sales),

  // Receipts
  getReceipts: async (): Promise<Receipt[]> => getData(STORAGE_KEYS.RECEIPTS, INITIAL_RECEIPTS),
  saveReceipts: async (receipts: Receipt[]) => saveData(STORAGE_KEYS.RECEIPTS, receipts),

  // Payments
  getPayments: async (): Promise<Payment[]> => getData(STORAGE_KEYS.PAYMENTS, INITIAL_PAYMENTS),
  savePayments: async (payments: Payment[]) => saveData(STORAGE_KEYS.PAYMENTS, payments),

  // Users
  getUsers: async (): Promise<User[]> => getData(STORAGE_KEYS.USERS, INITIAL_USERS),
  saveUsers: async (users: User[]) => saveData(STORAGE_KEYS.USERS, users),
};