
import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Receipt, Customer, Sale } from '../types';
import { PAYMENT_MODES } from '../constants';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (receipt: Receipt) => void;
  initialReceipt?: Receipt;
  customers: Customer[];
  sales: Sale[];
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ isOpen, onClose, onSave, initialReceipt, customers, sales }) => {
  const [formData, setFormData] = useState<Receipt>({
    id: '',
    date: new Date().toISOString().split('T')[0],
    customerId: '',
    customerName: '',
    state: '',
    city: '',
    soId: '',
    invoiceNum: '',
    paymentMode: PAYMENT_MODES[0],
    amountReceived: 0,
  });

  useEffect(() => {
    if (initialReceipt) {
      setFormData(initialReceipt);
    } else {
      const firstCustomer = customers[0];
      const customerSales = sales.filter(s => s.customerId === firstCustomer?.id);
      const firstSale = customerSales[0];

      setFormData({
        id: `TRX-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
        date: new Date().toISOString().split('T')[0],
        customerId: firstCustomer?.id || '',
        customerName: firstCustomer?.name || '',
        state: firstCustomer?.state || '',
        city: firstCustomer?.city || '',
        soId: firstSale?.id || '',
        invoiceNum: firstSale?.invoiceNum || '',
        paymentMode: PAYMENT_MODES[0],
        amountReceived: 0,
      });
    }
  }, [initialReceipt, isOpen, customers, sales]);

  const handleCustomerChange = (custId: string) => {
    const cust = customers.find(c => c.id === custId);
    if (cust) {
      const customerSales = sales.filter(s => s.customerId === cust.id);
      const firstSale = customerSales[0];
      
      setFormData({
        ...formData,
        customerId: cust.id,
        customerName: cust.name,
        state: cust.state,
        city: cust.city,
        soId: firstSale?.id || '',
        invoiceNum: firstSale?.invoiceNum || ''
      });
    }
  };

  const handleSaleChange = (soId: string) => {
    const sale = sales.find(s => s.id === soId);
    if (sale) {
      setFormData({
        ...formData,
        soId: sale.id,
        invoiceNum: sale.invoiceNum
      });
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900 bg-opacity-50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="text-xl font-bold text-slate-800">{initialReceipt ? 'Edit Receipt' : 'Record New Receipt'}</h2>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <form className="p-6 grid grid-cols-2 gap-4" onSubmit={(e) => {
          e.preventDefault();
          onSave(formData);
        }}>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Transaction ID</label>
            <input type="text" readOnly className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-500 font-mono" value={formData.id} />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Payment Date</label>
            <input 
              type="date" 
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Select Customer</label>
            <select 
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.customerId}
              onChange={(e) => handleCustomerChange(e.target.value)}
            >
              <option value="">-- Select Customer --</option>
              {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Related Sales Order</label>
            <select 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.soId}
              onChange={(e) => handleSaleChange(e.target.value)}
            >
              <option value="">-- Select SO (Optional) --</option>
              {sales.filter(s => s.customerId === formData.customerId).map(s => (
                <option key={s.id} value={s.id}>{s.id} (Inv: {s.invoiceNum})</option>
              ))}
            </select>
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Invoice Number</label>
            <input 
              type="text" 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.invoiceNum}
              onChange={(e) => setFormData({ ...formData, invoiceNum: e.target.value })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Payment Mode</label>
            <select 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.paymentMode}
              onChange={(e) => setFormData({ ...formData, paymentMode: e.target.value })}
            >
              {PAYMENT_MODES.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Amount Received ($)</label>
            <input 
              type="number" 
              min="0"
              step="0.01"
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg font-bold text-emerald-600"
              value={formData.amountReceived}
              onChange={(e) => setFormData({ ...formData, amountReceived: parseFloat(e.target.value) || 0 })}
            />
          </div>

          <div className="col-span-2 flex justify-end gap-3 mt-6">
            <button type="button" onClick={onClose} className="px-6 py-2 border border-slate-200 text-slate-600 font-semibold rounded-lg hover:bg-slate-50 transition-colors">
              Cancel
            </button>
            <button type="submit" className="px-6 py-2 bg-emerald-600 text-white font-semibold rounded-lg hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200">
              {initialReceipt ? 'Update Transaction' : 'Record Payment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
