
import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Payment, Supplier, Purchase } from '../types';
import { PAYMENT_MODES } from '../constants';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (payment: Payment) => void;
  initialPayment?: Payment;
  suppliers: Supplier[];
  purchases: Purchase[];
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, onSave, initialPayment, suppliers, purchases }) => {
  const [formData, setFormData] = useState<Payment>({
    id: '',
    date: new Date().toISOString().split('T')[0],
    supplierId: '',
    supplierName: '',
    state: '',
    city: '',
    poId: '',
    billNum: '',
    paymentMode: PAYMENT_MODES[0],
    amountPaid: 0,
  });

  useEffect(() => {
    if (initialPayment) {
      setFormData(initialPayment);
    } else {
      const firstSupplier = suppliers[0];
      const supplierPurchases = purchases.filter(p => p.supplierId === firstSupplier?.id);
      const firstPurchase = supplierPurchases[0];

      setFormData({
        id: `PMT-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
        date: new Date().toISOString().split('T')[0],
        supplierId: firstSupplier?.id || '',
        supplierName: firstSupplier?.name || '',
        state: firstSupplier?.state || '',
        city: firstSupplier?.city || '',
        poId: firstPurchase?.id || '',
        billNum: firstPurchase?.billNum || '',
        paymentMode: PAYMENT_MODES[0],
        amountPaid: 0,
      });
    }
  }, [initialPayment, isOpen, suppliers, purchases]);

  const handleSupplierChange = (supId: string) => {
    const sup = suppliers.find(s => s.id === supId);
    if (sup) {
      const supplierPurchases = purchases.filter(p => p.supplierId === sup.id);
      const firstPurchase = supplierPurchases[0];
      
      setFormData({
        ...formData,
        supplierId: sup.id,
        supplierName: sup.name,
        state: sup.state,
        city: sup.city,
        poId: firstPurchase?.id || '',
        billNum: firstPurchase?.billNum || ''
      });
    }
  };

  const handlePurchaseChange = (poId: string) => {
    const purchase = purchases.find(p => p.id === poId);
    if (purchase) {
      setFormData({
        ...formData,
        poId: purchase.id,
        billNum: purchase.billNum
      });
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900 bg-opacity-50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="text-xl font-bold text-slate-800">{initialPayment ? 'Edit Payment' : 'Record New Payment'}</h2>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <form className="p-6 grid grid-cols-2 gap-4" onSubmit={(e) => {
          e.preventDefault();
          onSave(formData);
        }}>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Transaction ID</label>
            <input type="text" readOnly className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-500 font-mono" value={formData.id} />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Payment Date</label>
            <input 
              type="date" 
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Select Supplier</label>
            <select 
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.supplierId}
              onChange={(e) => handleSupplierChange(e.target.value)}
            >
              <option value="">-- Select Supplier --</option>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Related Purchase Order</label>
            <select 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.poId}
              onChange={(e) => handlePurchaseChange(e.target.value)}
            >
              <option value="">-- Select PO (Optional) --</option>
              {purchases.filter(p => p.supplierId === formData.supplierId).map(p => (
                <option key={p.id} value={p.id}>{p.id} (Bill: {p.billNum})</option>
              ))}
            </select>
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Bill Number</label>
            <input 
              type="text" 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.billNum}
              onChange={(e) => setFormData({ ...formData, billNum: e.target.value })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Payment Mode</label>
            <select 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.paymentMode}
              onChange={(e) => setFormData({ ...formData, paymentMode: e.target.value })}
            >
              {PAYMENT_MODES.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Amount Paid ($)</label>
            <input 
              type="number" 
              min="0"
              step="0.01"
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg font-bold text-rose-600"
              value={formData.amountPaid}
              onChange={(e) => setFormData({ ...formData, amountPaid: parseFloat(e.target.value) || 0 })}
            />
          </div>

          <div className="col-span-2 flex justify-end gap-3 mt-6">
            <button type="button" onClick={onClose} className="px-6 py-2 border border-slate-200 text-slate-600 font-semibold rounded-lg hover:bg-slate-50 transition-colors">
              Cancel
            </button>
            <button type="submit" className="px-6 py-2 bg-rose-600 text-white font-semibold rounded-lg hover:bg-rose-700 transition-colors shadow-lg shadow-rose-200">
              {initialPayment ? 'Update Transaction' : 'Record Payment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
