
import React, { useState } from 'react';
import { Edit2, Trash2, ChevronDown, ChevronUp, Truck, CheckCircle2, XCircle, Clock } from 'lucide-react';
import { Sale } from '../types';

interface SalesTableProps {
  sales: Sale[];
  onEdit: (sale: Sale) => void;
  onDelete: (id: string) => void;
}

export const SalesTable: React.FC<SalesTableProps> = ({ sales, onEdit, onDelete }) => {
  const [sortField, setSortField] = useState<keyof Sale>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const handleSort = (field: keyof Sale) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedSales = [...sales].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];
    if (typeof aVal === 'string' && typeof bVal === 'string') {
      return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    }
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    }
    return 0;
  });

  const SortIcon = ({ field }: { field: keyof Sale }) => {
    if (sortField !== field) return <ChevronDown size={14} className="text-slate-300 ml-1" />;
    return sortDirection === 'asc' ? <ChevronUp size={14} className="text-blue-500 ml-1" /> : <ChevronDown size={14} className="text-blue-500 ml-1" />;
  };

  const getReceiptStatusBadge = (total: number, received: number) => {
    const balance = total - received;
    if (balance <= 0) return <span className="px-2 py-1 bg-emerald-100 text-emerald-700 rounded-full text-[10px] font-bold">PAID</span>;
    if (received > 0) return <span className="px-2 py-1 bg-amber-100 text-amber-700 rounded-full text-[10px] font-bold">PARTIAL</span>;
    return <span className="px-2 py-1 bg-rose-100 text-rose-700 rounded-full text-[10px] font-bold">UNPAID</span>;
  };

  const getShippingIcon = (status: Sale['shippingStatus']) => {
    switch (status) {
      case 'Delivered': return <CheckCircle2 size={14} className="text-emerald-500" />;
      case 'Shipped': return <Truck size={14} className="text-blue-500" />;
      case 'Pending': return <Clock size={14} className="text-amber-500" />;
      case 'Cancelled': return <XCircle size={14} className="text-rose-500" />;
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-full">
      <div className="overflow-x-auto custom-scrollbar flex-grow">
        <table className="w-full text-left border-collapse min-w-[1300px]">
          <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 z-10">
            <tr>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer" onClick={() => handleSort('date')}>
                <div className="flex items-center">SO Date <SortIcon field="date" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer" onClick={() => handleSort('id')}>
                <div className="flex items-center">SO ID <SortIcon field="id" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Customer Info</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Invoice Num</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Location</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Total SO Amount</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Total Received</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">SO Balance</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-center">Receipt Status</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-center">Shipping Status</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sortedSales.map((so) => {
              const balance = so.totalAmount - so.totalReceived;
              return (
                <tr key={so.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-4 py-4 text-sm text-slate-500">{so.date}</td>
                  <td className="px-4 py-4 text-sm font-bold text-blue-600">{so.id}</td>
                  <td className="px-4 py-4 text-sm">
                    <div className="font-semibold text-slate-800">{so.customerName}</div>
                    <div className="text-[10px] text-slate-400 uppercase tracking-tighter">{so.customerId}</div>
                  </td>
                  <td className="px-4 py-4 text-sm text-slate-600 font-mono">{so.invoiceNum}</td>
                  <td className="px-4 py-4 text-sm text-slate-500">
                    {so.city}, {so.state}
                  </td>
                  <td className="px-4 py-4 text-sm text-right font-medium text-slate-900">
                    ${so.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-4 text-sm text-right text-emerald-600">
                    ${so.totalReceived.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                  <td className={`px-4 py-4 text-sm text-right font-bold ${balance > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                    ${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-4 text-center">
                    {getReceiptStatusBadge(so.totalAmount, so.totalReceived)}
                  </td>
                  <td className="px-4 py-4 text-center">
                    <div className="flex items-center justify-center gap-1.5 px-2 py-1 rounded-lg border border-slate-100 bg-white shadow-sm w-max mx-auto text-[10px] font-bold text-slate-600">
                      {getShippingIcon(so.shippingStatus)}
                      {so.shippingStatus.toUpperCase()}
                    </div>
                  </td>
                  <td className="px-4 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => onEdit(so)} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                        <Edit2 size={16} />
                      </button>
                      <button onClick={() => onDelete(so.id)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
