
import React from 'react';
import { Users, UserPlus, ShieldCheck, Activity } from 'lucide-react';
import { User } from '../types';

interface UserStatsProps {
  users: User[];
}

export const UserStats: React.FC<UserStatsProps> = ({ users }) => {
  const activeUsers = users.filter(u => u.status === 'Active').length;
  const adminCount = users.filter(u => u.role === 'Admin').length;
  const newThisWeek = users.filter(u => u.lastLogin.includes('2024')).length; // Mock logic for "New/Recent"

  const stats = [
    { 
      label: 'Total System Users', 
      value: users.length, 
      icon: Users, 
      color: 'bg-blue-500', 
      textColor: 'text-blue-600' 
    },
    { 
      label: 'Active Sessions', 
      value: activeUsers, 
      icon: Activity, 
      color: 'bg-emerald-500', 
      textColor: 'text-emerald-600' 
    },
    { 
      label: 'Admin Privileges', 
      value: adminCount, 
      icon: ShieldCheck, 
      color: 'bg-rose-500', 
      textColor: 'text-rose-600' 
    },
    { 
      label: 'Recent Logins', 
      value: newThisWeek, 
      icon: UserPlus, 
      color: 'bg-indigo-500', 
      textColor: 'text-indigo-600' 
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, idx) => (
        <div key={idx} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className={`p-2 rounded-lg ${stat.color} bg-opacity-10 ${stat.textColor}`}>
              <stat.icon size={24} />
            </div>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">{stat.label}</h3>
          <p className="text-2xl font-bold text-slate-800 mt-1">{stat.value}</p>
        </div>
      ))}
    </div>
  );
};
