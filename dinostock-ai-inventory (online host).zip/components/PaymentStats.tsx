
import React from 'react';
import { CreditCard, Landmark, TrendingDown, Calendar } from 'lucide-react';
import { Payment } from '../types';

interface PaymentStatsProps {
  payments: Payment[];
}

export const PaymentStats: React.FC<PaymentStatsProps> = ({ payments }) => {
  const totalPaid = payments.reduce((acc, p) => acc + p.amountPaid, 0);
  
  const today = new Date().toISOString().split('T')[0];
  const todayOutflow = payments
    .filter(p => p.date === today)
    .reduce((acc, p) => acc + p.amountPaid, 0);

  const modeCounts: Record<string, number> = {};
  payments.forEach(p => {
    modeCounts[p.paymentMode] = (modeCounts[p.paymentMode] || 0) + 1;
  });
  const topMode = Object.entries(modeCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

  const stats = [
    { 
      label: 'Total Paid Out', 
      value: `$${totalPaid.toLocaleString()}`, 
      icon: TrendingDown, 
      color: 'bg-rose-500', 
      textColor: 'text-rose-600' 
    },
    { 
      label: 'Today\'s Cash Outflow', 
      value: `$${todayOutflow.toLocaleString()}`, 
      icon: Calendar, 
      color: 'bg-blue-500', 
      textColor: 'text-blue-600' 
    },
    { 
      label: 'Total Transactions', 
      value: payments.length, 
      icon: CreditCard, 
      color: 'bg-amber-500', 
      textColor: 'text-amber-600' 
    },
    { 
      label: 'Primary PMT Mode', 
      value: topMode, 
      icon: Landmark, 
      color: 'bg-indigo-500', 
      textColor: 'text-indigo-600' 
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, idx) => (
        <div key={idx} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className={`p-2 rounded-lg ${stat.color} bg-opacity-10 ${stat.textColor}`}>
              <stat.icon size={24} />
            </div>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">{stat.label}</h3>
          <p className="text-2xl font-bold text-slate-800 mt-1">{stat.value}</p>
        </div>
      ))}
    </div>
  );
};
