
import React, { useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Package, 
  ShoppingBag, 
  AlertCircle, 
  ArrowUpRight, 
  ArrowDownRight, 
  Activity, 
  Clock, 
  FileText,
  DollarSign,
  Sparkles,
  Users,
  Trophy,
  Layers,
  Archive
} from 'lucide-react';
import { InventoryItem, Sale, Purchase, GeminiInsight, Customer } from '../types';

interface DashboardPageProps {
  items: InventoryItem[];
  sales: Sale[];
  purchases: Purchase[];
  insights: GeminiInsight[];
  customers: Customer[];
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ items, sales, purchases, insights, customers }) => {
  // Calculations
  const metrics = useMemo(() => {
    const totalInventoryValue = items.reduce((sum, i) => sum + (i.qtyPurchased - i.qtySold) * 100, 0); // Mock value
    const totalSales = sales.reduce((sum, s) => sum + s.totalAmount, 0);
    const lowStockItems = items.filter(i => (i.qtyPurchased - i.qtySold) <= i.reorderLevel);
    const pendingPurchases = purchases.filter(p => p.shippingStatus !== 'Delivered').length;

    return {
      totalInventoryValue,
      totalSales,
      lowStockCount: lowStockItems.length,
      lowStockItems,
      pendingPurchases
    };
  }, [items, sales, purchases]);

  // Top Selling Items
  const topSellingItems = useMemo(() => {
    return [...items].sort((a, b) => b.qtySold - a.qtySold).slice(0, 5);
  }, [items]);

  // Most Available Products
  const mostAvailableProducts = useMemo(() => {
    return [...items].sort((a, b) => (b.qtyPurchased - b.qtySold) - (a.qtyPurchased - a.qtySold)).slice(0, 5);
  }, [items]);

  // Top Customers
  const topCustomers = useMemo(() => {
    return [...customers].sort((a, b) => b.purchases - a.purchases).slice(0, 10);
  }, [customers]);

  // Sales By Category
  const salesByCategory = useMemo(() => {
    const categories = Array.from(new Set(items.map(i => i.category)));
    return categories.map(cat => {
      const totalSold = items.filter(i => i.category === cat).reduce((sum, i) => sum + i.qtySold, 0);
      return { name: cat, totalSold };
    }).sort((a, b) => b.totalSold - a.totalSold);
  }, [items]);

  // Combined Recent Activity
  const recentActivity = useMemo(() => {
    const all = [
      ...sales.map(s => ({ ...s, type: 'SALE' as const })),
      ...purchases.map(p => ({ ...p, type: 'PURCHASE' as const }))
    ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    return all.slice(0, 5);
  }, [sales, purchases]);

  const maxSold = Math.max(...salesByCategory.map(c => c.totalSold), 1);

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-12">
      {/* KPI Header */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <DashboardMetricCard 
          title="Inventory Assets" 
          value={`$${metrics.totalInventoryValue.toLocaleString()}`} 
          subtitle="Total Market Value"
          icon={<Package size={24} />} 
          color="blue"
        />
        <DashboardMetricCard 
          title="Monthly Revenue" 
          value={`$${metrics.totalSales.toLocaleString()}`} 
          subtitle="+14% from last month"
          icon={<TrendingUp size={24} />} 
          color="emerald"
          trend="up"
        />
        <DashboardMetricCard 
          title="Supply Alerts" 
          value={metrics.lowStockCount.toString()} 
          subtitle="Items below reorder level"
          icon={<AlertCircle size={24} />} 
          color="amber"
          isAlert={metrics.lowStockCount > 0}
        />
        <DashboardMetricCard 
          title="Active Shipments" 
          value={metrics.pendingPurchases.toString()} 
          subtitle="Inbound supply chain"
          icon={<ShoppingBag size={24} />} 
          color="indigo"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Row 1: Left - Category Performance & Recent Activity */}
        <div className="lg:col-span-2 space-y-6">
          {/* Sales By Category Chart */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <Layers className="text-blue-600" size={20} />
                <h3 className="text-lg font-bold text-slate-800">Sales By Category</h3>
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Inventory Distribution</span>
            </div>
            <div className="space-y-4">
              {salesByCategory.map((cat, idx) => (
                <div key={idx} className="space-y-1.5">
                  <div className="flex justify-between items-center text-xs font-bold">
                    <span className="text-slate-600">{cat.name}</span>
                    <span className="text-slate-900">{cat.totalSold} Units Sold</span>
                  </div>
                  <div className="h-3 w-full bg-slate-50 rounded-full overflow-hidden border border-slate-100">
                    <div 
                      className="h-full bg-blue-500 rounded-full transition-all duration-1000"
                      style={{ width: `${(cat.totalSold / maxSold) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* AI Insight Highlight */}
          {insights.length > 0 && (
            <div className="bg-gradient-to-r from-indigo-600 to-blue-600 rounded-2xl p-6 text-white shadow-lg shadow-indigo-100 relative overflow-hidden">
              <Sparkles className="absolute top-0 right-0 m-4 opacity-20" size={64} />
              <div className="relative z-10">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] font-black uppercase tracking-widest bg-white/20 px-2 py-0.5 rounded">Featured AI Insight</span>
                </div>
                <h4 className="text-xl font-bold mb-1">{insights[0].title}</h4>
                <p className="text-indigo-100 text-sm opacity-90 leading-relaxed max-w-2xl">{insights[0].description}</p>
              </div>
            </div>
          )}

          {/* Product Rankings: Top Selling vs Most Available */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Top Selling Items */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 mb-6">
                <Trophy className="text-amber-500" size={18} />
                <h3 className="font-bold text-slate-800">Top Selling Items</h3>
              </div>
              <div className="space-y-4">
                {topSellingItems.map((item, idx) => (
                  <div key={item.id} className="flex items-center justify-between group">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-xs font-bold text-slate-500 border border-slate-100 group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors">
                        {idx + 1}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-bold text-slate-800 truncate">{item.name}</p>
                        <p className="text-[10px] text-slate-400 uppercase tracking-widest">{item.category}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-black text-slate-900">{item.qtySold}</p>
                      <p className="text-[9px] font-bold text-emerald-600 uppercase">Sales</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Most Available Product */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 mb-6">
                <Archive className="text-blue-500" size={18} />
                <h3 className="font-bold text-slate-800">High Availability</h3>
              </div>
              <div className="space-y-4">
                {mostAvailableProducts.map((item) => {
                  const remaining = item.qtyPurchased - item.qtySold;
                  return (
                    <div key={item.id} className="flex items-center justify-between group">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-xs font-bold text-slate-500 border border-slate-100 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                          <Package size={14} />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-bold text-slate-800 truncate">{item.name}</p>
                          <p className="text-[10px] text-slate-400 uppercase tracking-widest">{item.id}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-black text-slate-900">{remaining}</p>
                        <p className="text-[9px] font-bold text-blue-600 uppercase">Available</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Sections */}
        <div className="space-y-6">
          {/* Top 10 Customers */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-800">
                <Users size={16} className="text-indigo-600" />
                <h3 className="font-bold text-sm">Top 10 Customers</h3>
              </div>
            </div>
            <div className="divide-y divide-slate-50 max-h-[400px] overflow-y-auto custom-scrollbar">
              {topCustomers.map((cust, idx) => (
                <div key={cust.id} className="p-3 hover:bg-slate-50 transition-colors flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-black text-slate-300 w-4">{idx + 1}</span>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-800 truncate">{cust.name}</p>
                      <p className="text-[9px] text-slate-400 truncate">{cust.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-black text-indigo-600">${cust.purchases.toLocaleString()}</p>
                    <p className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter">Life Volume</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Low Stock Products List */}
          <div className="bg-white rounded-2xl border border-rose-100 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-rose-50 bg-rose-50/30 flex items-center justify-between">
              <div className="flex items-center gap-2 text-rose-800">
                <AlertCircle size={16} className="text-rose-600" />
                <h3 className="font-bold text-sm">Critical Stock Alerts</h3>
              </div>
              <span className="text-[10px] font-black text-rose-600 bg-rose-100 px-2 py-0.5 rounded-full">
                {metrics.lowStockCount} Items
              </span>
            </div>
            <div className="p-4 space-y-3">
              {metrics.lowStockItems.length > 0 ? (
                metrics.lowStockItems.slice(0, 5).map(item => {
                  const remaining = item.qtyPurchased - item.qtySold;
                  return (
                    <div key={item.id} className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100 group hover:border-rose-200 transition-all">
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-800 truncate">{item.name}</p>
                        <p className="text-[9px] text-slate-500">Target Reorder: {item.reorderLevel}</p>
                      </div>
                      <div className="text-right flex flex-col items-end">
                        <span className={`text-xs font-black ${remaining <= 0 ? 'text-rose-600' : 'text-amber-600'}`}>
                          {remaining} Left
                        </span>
                        <div className="w-12 h-1 bg-slate-200 rounded-full mt-1 overflow-hidden">
                          <div 
                            className={`h-full ${remaining <= 0 ? 'bg-rose-500' : 'bg-amber-500'}`} 
                            style={{ width: `${Math.max(5, (remaining / item.reorderLevel) * 100)}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <p className="text-center text-xs text-slate-400 py-4 italic">No critical stock levels detected.</p>
              )}
              {metrics.lowStockCount > 5 && (
                <button className="w-full text-center text-[10px] font-bold text-slate-500 uppercase tracking-widest py-1 hover:text-blue-600 transition-colors">
                  + {metrics.lowStockCount - 5} more alerts
                </button>
              )}
            </div>
          </div>

          {/* Real-time Activity Feed */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-800">
                <Clock size={16} />
                <h3 className="font-bold text-sm">Recent Transactions</h3>
              </div>
            </div>
            <div className="divide-y divide-slate-50">
              {recentActivity.map((act, idx) => (
                <div key={idx} className="p-3 hover:bg-slate-50 transition-colors group">
                  <div className="flex items-start gap-3">
                    <div className={`p-1.5 rounded-lg ${act.type === 'SALE' ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'}`}>
                      {act.type === 'SALE' ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                    </div>
                    <div className="flex-grow min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-[11px] font-bold text-slate-800 truncate">
                          {act.type === 'SALE' ? (act as Sale).customerName : (act as Purchase).supplierName}
                        </p>
                        <span className="text-[9px] font-medium text-slate-400">{act.date}</span>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                         <span className={`text-[9px] font-black tracking-tighter ${act.type === 'SALE' ? 'text-emerald-600' : 'text-blue-600'}`}>
                          {act.type === 'SALE' ? 'SALES OUT' : 'SUPPLY IN'}
                        </span>
                        <p className="text-[11px] font-black text-slate-900">
                          ${act.totalAmount.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const DashboardMetricCard = ({ 
  title, 
  value, 
  subtitle, 
  icon, 
  color, 
  trend,
  isAlert 
}: { 
  title: string; 
  value: string; 
  subtitle: string; 
  icon: React.ReactNode; 
  color: string;
  trend?: 'up' | 'down';
  isAlert?: boolean;
}) => {
  const colors: Record<string, string> = {
    blue: 'bg-blue-500 text-blue-600 border-blue-100',
    emerald: 'bg-emerald-500 text-emerald-600 border-emerald-100',
    amber: 'bg-amber-500 text-amber-600 border-amber-100',
    indigo: 'bg-indigo-500 text-indigo-600 border-indigo-100',
  };

  return (
    <div className={`bg-white p-6 rounded-2xl border ${isAlert ? 'border-rose-200 animate-pulse' : 'border-slate-200'} shadow-sm hover:shadow-md transition-all group`}>
      <div className="flex items-center justify-between mb-4">
        <div className={`p-2.5 rounded-xl bg-opacity-10 ${colors[color].split(' ')[1]} ${colors[color].split(' ')[0]}`}>
          {icon}
        </div>
        {trend && (
          <div className={`flex items-center gap-0.5 text-[10px] font-black ${trend === 'up' ? 'text-emerald-600' : 'text-rose-600'} bg-opacity-10 px-2 py-0.5 rounded-full border border-current border-opacity-20`}>
            {trend === 'up' ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
            14%
          </div>
        )}
      </div>
      <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-widest">{title}</h3>
      <div className="flex items-baseline gap-2 mt-1">
        <p className="text-2xl font-black text-slate-800 tracking-tight">{value}</p>
        <p className="text-[10px] font-medium text-slate-400 truncate">{subtitle}</p>
      </div>
    </div>
  );
};
