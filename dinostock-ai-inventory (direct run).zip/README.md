# 🦖 DinoStock AI Inventory

**DinoStock AI** is a world-class, intelligent inventory and warehouse management system designed for modern enterprises. It combines robust transactional tracking with state-of-the-art AI insights powered by Google Gemini 3.

---

## 🌟 Key Features

### 📦 Advanced Inventory Management
- **Detailed Tracking**: Manage items with granular attributes: Item ID, Type, Category, Subcategory, and Name.
- **Stock Intelligence**: Real-time tracking of QTY Purchased, QTY Sold, and Remaining stock.
- **Reorder Alerts**: Automated visual indicators for items that fall below critical reorder levels.

### 💰 Full Financial Lifecycle
- **Procurement (Purchases)**: Track purchase orders (POs), supplier bills, and payment status.
- **Revenue (Sales)**: Manage sales orders (SOs), customer invoices, and shipping fulfillment.
- **Cash Flow**: Dedicated modules for **Receipts** (Cash In) and **Payments** (Cash Out) with support for multiple payment modes (Bank Transfer, Credit Card, Cash, etc.).

### 📊 Business Intelligence & Reporting
- **Dynamic Dashboard**: High-level KPIs, inventory distribution charts, and real-time activity feeds.
- **Advanced Reports**: 
  - **Most Available Products**: Identify overstocked items.
  - **Top Selling Products**: Track high-velocity stock.
  - **Stock Balance**: Full audit trail of current holdings.
  - **Low Critical Alerts**: Immediate list of items needing replenishment.
  - **Category Performance**: See which business segments drive the most revenue.
  - **Transaction Logs**: Date-filtered reports for all Purchased and Sold products.
- **Printable Tables**: Professional, tabular reports optimized for paper and PDF export.

### 🤖 Gemini AI Integration
- **Predictive Insights**: Uses Google Gemini 3 to analyze inventory levels and sales trends.
- **Actionable Suggestions**: Provides high, medium, and low priority business optimizations (e.g., "Liquidate slow-moving stock" or "Increase buffer for high-demand electronics").

---

## 🛠 Tech Stack

- **Frontend**: React 19 (Hooks, Context, Memoization)
- **Styling**: Tailwind CSS (Utility-first, responsive, accessible)
- **Icons**: Lucide React
- **AI Engine**: Google GenAI SDK (@google/genai)
- **Typography**: Inter (High-legibility sans-serif)

---

## 🚀 Getting Started

### Prerequisites
- An API Key from [Google AI Studio](https://aistudio.google.com/).

### Environment Configuration
The application requires the following environment variable:
```env
API_KEY=your_gemini_api_key_here
```

### Installation
1. Clone the repository.
2. Ensure you have the latest dependencies.
3. Launch the application in a modern browser.

---

## 📂 Project Structure

```text
/
├── components/          # Specialized UI modules
│   ├── DashboardPage    # KPI Overview & Visualizations
│   ├── ReportsPage      # Tabular, Printable Business Logic
│   ├── InventoryTable   # Main Stock Management
│   ├── ...              # Modals, Stats, and Management Tables
├── services/            # API & External Logic
│   └── geminiService    # Google GenAI Integration
├── constants.ts         # Mock data and system enums
├── types.ts             # TypeScript interfaces
├── App.tsx              # Main Application Controller
└── index.tsx            # React Entry Point
```

---

## 👤 User Management

DinoStock features a tiered access system:
- **Admin (e.g., Dino Abdela)**: Full system control and security settings.
- **Manager**: Oversees transactions and generates reports.
- **Staff**: Handles day-to-day inventory updates and order fulfillment.

---

## 📝 License

&copy; 2024 DinoStock AI Inventory Systems. Optimized for efficiency and scale.