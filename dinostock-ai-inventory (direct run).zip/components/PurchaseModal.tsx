
import React, { useState, useEffect } from 'react';
import { X, Calendar } from 'lucide-react';
import { Purchase, Supplier } from '../types';
import { SHIPPING_STATUSES } from '../constants';

interface PurchaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (purchase: Purchase) => void;
  initialPurchase?: Purchase;
  suppliers: Supplier[];
}

export const PurchaseModal: React.FC<PurchaseModalProps> = ({ isOpen, onClose, onSave, initialPurchase, suppliers }) => {
  const [formData, setFormData] = useState<Purchase>({
    id: '',
    date: new Date().toISOString().split('T')[0],
    supplierId: '',
    supplierName: '',
    billNum: '',
    state: '',
    city: '',
    totalAmount: 0,
    totalPaid: 0,
    shippingStatus: 'Pending',
  });

  useEffect(() => {
    if (initialPurchase) {
      setFormData(initialPurchase);
    } else {
      setFormData({
        id: `PO-2024-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
        date: new Date().toISOString().split('T')[0],
        supplierId: suppliers[0]?.id || '',
        supplierName: suppliers[0]?.name || '',
        billNum: `INV-${Math.floor(Math.random() * 10000)}`,
        state: suppliers[0]?.state || '',
        city: suppliers[0]?.city || '',
        totalAmount: 0,
        totalPaid: 0,
        shippingStatus: 'Pending',
      });
    }
  }, [initialPurchase, isOpen, suppliers]);

  const handleSupplierChange = (supId: string) => {
    const sup = suppliers.find(s => s.id === supId);
    if (sup) {
      setFormData({
        ...formData,
        supplierId: sup.id,
        supplierName: sup.name,
        state: sup.state,
        city: sup.city
      });
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900 bg-opacity-50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="text-xl font-bold text-slate-800">{initialPurchase ? 'Edit Purchase Order' : 'Create New PO'}</h2>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <form className="p-6 grid grid-cols-2 gap-4" onSubmit={(e) => {
          e.preventDefault();
          onSave(formData);
        }}>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">PO ID</label>
            <input type="text" readOnly className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-500" value={formData.id} />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Order Date</label>
            <input 
              type="date" 
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            />
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Select Supplier</label>
            <select 
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.supplierId}
              onChange={(e) => handleSupplierChange(e.target.value)}
            >
              <option value="">-- Select Supplier --</option>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name} ({s.id})</option>)}
            </select>
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Bill Number</label>
            <input 
              type="text" 
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.billNum}
              onChange={(e) => setFormData({ ...formData, billNum: e.target.value })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Shipping Status</label>
            <select 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.shippingStatus}
              onChange={(e) => setFormData({ ...formData, shippingStatus: e.target.value as any })}
            >
              {SHIPPING_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Total Amount ($)</label>
            <input 
              type="number" 
              min="0"
              step="0.01"
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.totalAmount}
              onChange={(e) => setFormData({ ...formData, totalAmount: parseFloat(e.target.value) || 0 })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Total Paid ($)</label>
            <input 
              type="number" 
              min="0"
              step="0.01"
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.totalPaid}
              onChange={(e) => setFormData({ ...formData, totalPaid: parseFloat(e.target.value) || 0 })}
            />
          </div>

          <div className="col-span-2 flex justify-end gap-3 mt-6">
            <button type="button" onClick={onClose} className="px-6 py-2 border border-slate-200 text-slate-600 font-semibold rounded-lg hover:bg-slate-50 transition-colors">
              Cancel
            </button>
            <button type="submit" className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200">
              {initialPurchase ? 'Update PO' : 'Create Order'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
