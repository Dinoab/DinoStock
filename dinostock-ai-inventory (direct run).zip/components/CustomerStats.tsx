
import React from 'react';
import { Users, CreditCard, HandCoins, Activity } from 'lucide-react';
import { Customer } from '../types';

interface CustomerStatsProps {
  customers: Customer[];
}

export const CustomerStats: React.FC<CustomerStatsProps> = ({ customers }) => {
  const totalRevenue = customers.reduce((acc, c) => acc + c.purchases, 0);
  const totalReceived = customers.reduce((acc, c) => acc + c.payments, 0);
  const totalOutstanding = totalRevenue - totalReceived;
  const topCustomer = customers.reduce((prev, current) => (prev.purchases > current.purchases) ? prev : current, customers[0]);

  const stats = [
    { 
      label: 'Total Customers', 
      value: customers.length, 
      icon: Users, 
      color: 'bg-blue-500', 
      textColor: 'text-blue-600' 
    },
    { 
      label: 'Total Revenue', 
      value: `$${totalRevenue.toLocaleString()}`, 
      icon: Activity, 
      color: 'bg-indigo-500', 
      textColor: 'text-indigo-600' 
    },
    { 
      label: 'Payments Received', 
      value: `$${totalReceived.toLocaleString()}`, 
      icon: HandCoins, 
      color: 'bg-emerald-500', 
      textColor: 'text-emerald-600' 
    },
    { 
      label: 'Receivables Balance', 
      value: `$${totalOutstanding.toLocaleString()}`, 
      icon: CreditCard, 
      color: 'bg-rose-500', 
      textColor: 'text-rose-600' 
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, idx) => (
        <div key={idx} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className={`p-2 rounded-lg ${stat.color} bg-opacity-10 ${stat.textColor}`}>
              <stat.icon size={24} />
            </div>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">{stat.label}</h3>
          <p className="text-2xl font-bold text-slate-800 mt-1">{stat.value}</p>
        </div>
      ))}
    </div>
  );
};
