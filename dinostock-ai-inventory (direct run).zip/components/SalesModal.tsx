
import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Sale, Customer } from '../types';
import { SHIPPING_STATUSES } from '../constants';

interface SalesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (sale: Sale) => void;
  initialSale?: Sale;
  customers: Customer[];
}

export const SalesModal: React.FC<SalesModalProps> = ({ isOpen, onClose, onSave, initialSale, customers }) => {
  const [formData, setFormData] = useState<Sale>({
    id: '',
    date: new Date().toISOString().split('T')[0],
    customerId: '',
    customerName: '',
    invoiceNum: '',
    state: '',
    city: '',
    totalAmount: 0,
    totalReceived: 0,
    shippingStatus: 'Pending',
  });

  useEffect(() => {
    if (initialSale) {
      setFormData(initialSale);
    } else {
      const firstCustomer = customers[0];
      setFormData({
        id: `SO-2024-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
        date: new Date().toISOString().split('T')[0],
        customerId: firstCustomer?.id || '',
        customerName: firstCustomer?.name || '',
        invoiceNum: `IN-${Math.floor(Math.random() * 10000)}`,
        state: firstCustomer?.state || '',
        city: firstCustomer?.city || '',
        totalAmount: 0,
        totalReceived: 0,
        shippingStatus: 'Pending',
      });
    }
  }, [initialSale, isOpen, customers]);

  const handleCustomerChange = (custId: string) => {
    const cust = customers.find(c => c.id === custId);
    if (cust) {
      setFormData({
        ...formData,
        customerId: cust.id,
        customerName: cust.name,
        state: cust.state,
        city: cust.city
      });
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900 bg-opacity-50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="text-xl font-bold text-slate-800">{initialSale ? 'Edit Sales Order' : 'Create New SO'}</h2>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <form className="p-6 grid grid-cols-2 gap-4" onSubmit={(e) => {
          e.preventDefault();
          onSave(formData);
        }}>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">SO ID</label>
            <input type="text" readOnly className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-500 font-mono" value={formData.id} />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Order Date</label>
            <input 
              type="date" 
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            />
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Select Customer</label>
            <select 
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.customerId}
              onChange={(e) => handleCustomerChange(e.target.value)}
            >
              <option value="">-- Select Customer --</option>
              {customers.map(c => <option key={c.id} value={c.id}>{c.name} ({c.id})</option>)}
            </select>
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Invoice Number</label>
            <input 
              type="text" 
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.invoiceNum}
              onChange={(e) => setFormData({ ...formData, invoiceNum: e.target.value })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Shipping Status</label>
            <select 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.shippingStatus}
              onChange={(e) => setFormData({ ...formData, shippingStatus: e.target.value as any })}
            >
              {SHIPPING_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Total SO Amount ($)</label>
            <input 
              type="number" 
              min="0"
              step="0.01"
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.totalAmount}
              onChange={(e) => setFormData({ ...formData, totalAmount: parseFloat(e.target.value) || 0 })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Total Received ($)</label>
            <input 
              type="number" 
              min="0"
              step="0.01"
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.totalReceived}
              onChange={(e) => setFormData({ ...formData, totalReceived: parseFloat(e.target.value) || 0 })}
            />
          </div>

          <div className="col-span-2 flex justify-end gap-3 mt-6">
            <button type="button" onClick={onClose} className="px-6 py-2 border border-slate-200 text-slate-600 font-semibold rounded-lg hover:bg-slate-50 transition-colors">
              Cancel
            </button>
            <button type="submit" className="px-6 py-2 bg-emerald-600 text-white font-semibold rounded-lg hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200">
              {initialSale ? 'Update SO' : 'Create Sales Order'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
