
import React from 'react';
import { Truck, Wallet, Landmark, BadgePercent } from 'lucide-react';
import { Supplier } from '../types';

interface SupplierStatsProps {
  suppliers: Supplier[];
}

export const SupplierStats: React.FC<SupplierStatsProps> = ({ suppliers }) => {
  const totalPurchases = suppliers.reduce((acc, s) => acc + s.purchases, 0);
  const totalPayments = suppliers.reduce((acc, s) => acc + s.payments, 0);
  const totalBalance = totalPurchases - totalPayments;
  const topSupplier = suppliers.reduce((prev, current) => (prev.purchases > current.purchases) ? prev : current, suppliers[0]);

  const stats = [
    { 
      label: 'Total Suppliers', 
      value: suppliers.length, 
      icon: Truck, 
      color: 'bg-blue-500', 
      textColor: 'text-blue-600' 
    },
    { 
      label: 'Outstanding Balance', 
      value: `$${totalBalance.toLocaleString()}`, 
      icon: Wallet, 
      color: 'bg-rose-500', 
      textColor: 'text-rose-600' 
    },
    { 
      label: 'Total Paid', 
      value: `$${totalPayments.toLocaleString()}`, 
      icon: Landmark, 
      color: 'bg-emerald-500', 
      textColor: 'text-emerald-600' 
    },
    { 
      label: 'Top Partner', 
      value: topSupplier?.name || 'N/A', 
      icon: BadgePercent, 
      color: 'bg-indigo-500', 
      textColor: 'text-indigo-600' 
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, idx) => (
        <div key={idx} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className={`p-2 rounded-lg ${stat.color} bg-opacity-10 ${stat.textColor}`}>
              <stat.icon size={24} />
            </div>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">{stat.label}</h3>
          <p className="text-2xl font-bold text-slate-800 mt-1">{stat.value}</p>
        </div>
      ))}
    </div>
  );
};
