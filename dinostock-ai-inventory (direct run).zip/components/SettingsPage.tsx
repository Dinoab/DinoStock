
import React, { useState } from 'react';
// Added PieChart to the imports
import { Save, Building, Bell, Globe, Sparkles, Shield, Trash2, Download, Cloud, CreditCard, PieChart } from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const [businessName, setBusinessName] = useState('DinoStock Solutions Inc.');
  const [currency, setCurrency] = useState('USD');
  const [dateFormat, setDateFormat] = useState('MM/DD/YYYY');
  const [aiEnabled, setAiEnabled] = useState(true);
  const [notifications, setNotifications] = useState({
    email: true,
    push: false,
    lowStock: true,
    weeklyReport: true,
  });

  const handleSave = () => {
    alert('Settings saved successfully!');
  };

  return (
    <div className="max-w-4xl mx-auto pb-20 animate-in fade-in duration-500">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Configuration Hub</h2>
          <p className="text-slate-500 text-sm">Tailor your inventory management experience</p>
        </div>
        <button 
          onClick={handleSave}
          className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-200 hover:bg-blue-700 transition-all active:scale-95"
        >
          <Save size={18} /> Save Changes
        </button>
      </div>

      <div className="space-y-6">
        {/* Business Profile */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex items-center gap-3">
            <Building className="text-blue-600" size={20} />
            <h3 className="font-bold text-slate-800">Business Profile</h3>
          </div>
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Company Name</label>
              <input 
                type="text" 
                value={businessName} 
                onChange={(e) => setBusinessName(e.target.value)}
                className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Business Category</label>
              <select className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all">
                <option>Retail & E-commerce</option>
                <option>Manufacturing</option>
                <option>Wholesale/Distribution</option>
                <option>Healthcare/Pharma</option>
              </select>
            </div>
            <div className="col-span-1 md:col-span-2 space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Support Email</label>
              <input 
                type="email" 
                defaultValue="admin@dinostock.solutions" 
                className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              />
            </div>
          </div>
        </div>

        {/* AI & Intelligence */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex items-center gap-3">
            <Sparkles className="text-indigo-600" size={20} />
            <h3 className="font-bold text-slate-800">AI & Analytics Configuration</h3>
          </div>
          <div className="p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-slate-800">Gemini Predictive Analytics</h4>
                <p className="text-slate-500 text-xs">Enable real-time inventory forecasting and risk detection</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked={aiEnabled} onChange={() => setAiEnabled(!aiEnabled)} className="sr-only peer" />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            <div className="h-px bg-slate-100"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Update Frequency</label>
                <select className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all">
                  <option>Every Hour</option>
                  <option>Every 6 Hours</option>
                  <option>Daily (Recommended)</option>
                  <option>Weekly</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Insight Focus</label>
                <select className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all">
                  <option>Profit Maximization</option>
                  <option>Waste Reduction</option>
                  <option>Customer Satisfaction</option>
                  <option>Stock Stability</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Localization & Preferences */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex items-center gap-3">
            <Globe className="text-emerald-600" size={20} />
            <h3 className="font-bold text-slate-800">Localization & Appearance</h3>
          </div>
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">System Currency</label>
              <select 
                value={currency} 
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              >
                <option value="USD">USD ($) - US Dollar</option>
                <option value="EUR">EUR (€) - Euro</option>
                <option value="GBP">GBP (£) - British Pound</option>
                <option value="INR">INR (₹) - Indian Rupee</option>
              </select>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Date Format</label>
              <select 
                value={dateFormat} 
                onChange={(e) => setDateFormat(e.target.value)}
                className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              >
                <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                <option value="YYYY-MM-DD">YYYY-MM-DD</option>
              </select>
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex items-center gap-3">
            <Bell className="text-amber-600" size={20} />
            <h3 className="font-bold text-slate-800">Communication Preferences</h3>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600"><Cloud size={16} /></div>
                <div>
                  <p className="text-sm font-semibold text-slate-800">Low Stock Alerts</p>
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Push & In-App</p>
                </div>
              </div>
              <input type="checkbox" checked={notifications.lowStock} onChange={() => setNotifications({...notifications, lowStock: !notifications.lowStock})} className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
            </div>
            <div className="flex items-center justify-between py-2 border-t border-slate-50">
              <div className="flex items-center gap-3">
                {/* Fixed the missing PieChart component */}
                <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600"><PieChart size={16} /></div>
                <div>
                  <p className="text-sm font-semibold text-slate-800">Weekly Business Digest</p>
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Email Subscription</p>
                </div>
              </div>
              <input type="checkbox" checked={notifications.weeklyReport} onChange={() => setNotifications({...notifications, weeklyReport: !notifications.weeklyReport})} className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
            </div>
          </div>
        </div>

        {/* Danger Zone */}
        <div className="bg-rose-50 rounded-2xl border border-rose-100 shadow-sm overflow-hidden p-6">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="text-rose-600" size={20} />
            <h3 className="font-bold text-rose-800">Maintenance & Security</h3>
          </div>
          <div className="flex flex-wrap gap-3">
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-rose-200 text-rose-600 rounded-xl text-sm font-bold hover:bg-rose-50 transition-all">
              <Trash2 size={16} /> Purge Inactive Data
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-xl text-sm font-bold hover:bg-slate-50 transition-all">
              <Download size={16} /> Full System Backup
            </button>
          </div>
          <p className="mt-4 text-[10px] text-rose-400 font-medium uppercase tracking-widest">Note: Some actions may require administrator privileges.</p>
        </div>
      </div>
    </div>
  );
};