
import React, { useState } from 'react';
import { Edit2, Trash2, ChevronDown, ChevronUp, AlertCircle, CheckCircle2, MoreVertical, Download } from 'lucide-react';
import { InventoryItem } from '../types';

interface InventoryTableProps {
  items: InventoryItem[];
  onEdit: (item: InventoryItem) => void;
  onDelete: (id: string) => void;
}

export const InventoryTable: React.FC<InventoryTableProps> = ({ items, onEdit, onDelete }) => {
  const [sortField, setSortField] = useState<keyof InventoryItem>('id');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const handleSort = (field: keyof InventoryItem) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedItems = [...items].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];
    if (typeof aVal === 'string' && typeof bVal === 'string') {
      return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    }
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    }
    return 0;
  });

  const SortIcon = ({ field }: { field: keyof InventoryItem }) => {
    if (sortField !== field) return <ChevronDown size={14} className="text-slate-300 ml-1" />;
    return sortDirection === 'asc' ? <ChevronUp size={14} className="text-blue-500 ml-1" /> : <ChevronDown size={14} className="text-blue-500 ml-1" />;
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-full">
      <div className="overflow-x-auto custom-scrollbar flex-grow">
        <table className="w-full text-left border-collapse min-w-[1200px]">
          <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 z-10">
            <tr>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('id')}>
                <div className="flex items-center">Item ID <SortIcon field="id" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('type')}>
                <div className="flex items-center">Item Type <SortIcon field="type" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('category')}>
                <div className="flex items-center">Category <SortIcon field="category" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('subcategory')}>
                <div className="flex items-center">Subcategory <SortIcon field="subcategory" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('name')}>
                <div className="flex items-center">Item Name <SortIcon field="name" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-center">QTY Purchased</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-center">QTY Sold</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-center">Remaining QTY</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-center">Reorder Level</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Reorder Status</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sortedItems.map((item) => {
              const remaining = item.qtyPurchased - item.qtySold;
              const reorderRequired = remaining <= item.reorderLevel;

              return (
                <tr key={item.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-4 py-4 text-sm font-medium text-blue-600">{item.id}</td>
                  <td className="px-4 py-4 text-sm text-slate-600">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      item.type === 'Finished Good' ? 'bg-indigo-100 text-indigo-700' :
                      item.type === 'Raw Material' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {item.type}
                    </span>
                  </td>
                  <td className="px-4 py-4 text-sm text-slate-600">{item.category}</td>
                  <td className="px-4 py-4 text-sm text-slate-400 italic">{item.subcategory}</td>
                  <td className="px-4 py-4 text-sm font-semibold text-slate-800">{item.name}</td>
                  <td className="px-4 py-4 text-sm text-slate-600 text-center">{item.qtyPurchased}</td>
                  <td className="px-4 py-4 text-sm text-slate-600 text-center">{item.qtySold}</td>
                  <td className={`px-4 py-4 text-sm text-center font-bold ${remaining <= 0 ? 'text-rose-600' : remaining <= item.reorderLevel ? 'text-amber-600' : 'text-slate-800'}`}>
                    {remaining}
                  </td>
                  <td className="px-4 py-4 text-sm text-slate-500 text-center">{item.reorderLevel}</td>
                  <td className="px-4 py-4">
                    {reorderRequired ? (
                      <div className="flex items-center text-rose-600 text-xs font-bold gap-1 bg-rose-50 px-2 py-1 rounded-full w-max">
                        <AlertCircle size={14} /> REQUIRED
                      </div>
                    ) : (
                      <div className="flex items-center text-emerald-600 text-xs font-bold gap-1 bg-emerald-50 px-2 py-1 rounded-full w-max">
                        <CheckCircle2 size={14} /> OK
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => onEdit(item)}
                        className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Edit Item"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => onDelete(item.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete Item"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
