
import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { InventoryItem } from '../types';
import { TYPES, CATEGORIES } from '../constants';

interface InventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: InventoryItem) => void;
  initialItem?: InventoryItem;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({ isOpen, onClose, onSave, initialItem }) => {
  const [formData, setFormData] = useState<InventoryItem>({
    id: '',
    type: TYPES[0],
    category: CATEGORIES[0],
    subcategory: '',
    name: '',
    qtyPurchased: 0,
    qtySold: 0,
    reorderLevel: 0,
  });

  useEffect(() => {
    if (initialItem) {
      setFormData(initialItem);
    } else {
      setFormData({
        id: `SKU-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
        type: TYPES[0],
        category: CATEGORIES[0],
        subcategory: '',
        name: '',
        qtyPurchased: 0,
        qtySold: 0,
        reorderLevel: 0,
      });
    }
  }, [initialItem, isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900 bg-opacity-50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="text-xl font-bold text-slate-800">{initialItem ? 'Edit Item' : 'Add New Inventory Item'}</h2>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <form className="p-6 grid grid-cols-2 gap-4" onSubmit={(e) => {
          e.preventDefault();
          onSave(formData);
        }}>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Item ID</label>
            <input 
              type="text" 
              required
              readOnly={!!initialItem}
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-slate-50"
              value={formData.id}
              onChange={(e) => setFormData({ ...formData, id: e.target.value })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Item Type</label>
            <select 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value })}
            >
              {TYPES.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Item Name</label>
            <input 
              type="text" 
              required
              placeholder="e.g. MacBook Pro M3"
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Category</label>
            <select 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            >
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Subcategory</label>
            <input 
              type="text" 
              placeholder="e.g. Laptops"
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.subcategory}
              onChange={(e) => setFormData({ ...formData, subcategory: e.target.value })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">QTY Purchased</label>
            <input 
              type="number" 
              min="0"
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.qtyPurchased}
              onChange={(e) => setFormData({ ...formData, qtyPurchased: parseInt(e.target.value) || 0 })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">QTY Sold</label>
            <input 
              type="number" 
              min="0"
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.qtySold}
              onChange={(e) => setFormData({ ...formData, qtySold: parseInt(e.target.value) || 0 })}
            />
          </div>
          <div className="col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Reorder Level</label>
            <input 
              type="number" 
              min="0"
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.reorderLevel}
              onChange={(e) => setFormData({ ...formData, reorderLevel: parseInt(e.target.value) || 0 })}
            />
          </div>

          <div className="col-span-2 flex justify-end gap-3 mt-6">
            <button 
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-slate-200 text-slate-600 font-semibold rounded-lg hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200"
            >
              {initialItem ? 'Update Item' : 'Save Item'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
