
import React, { useState } from 'react';
import { Edit2, Trash2, ChevronDown, ChevronUp, CreditCard, Banknote, Landmark, Smartphone, FileText } from 'lucide-react';
import { Receipt } from '../types';

interface ReceiptsTableProps {
  receipts: Receipt[];
  onEdit: (receipt: Receipt) => void;
  onDelete: (id: string) => void;
}

export const ReceiptsTable: React.FC<ReceiptsTableProps> = ({ receipts, onEdit, onDelete }) => {
  const [sortField, setSortField] = useState<keyof Receipt>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const handleSort = (field: keyof Receipt) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedReceipts = [...receipts].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];
    if (typeof aVal === 'string' && typeof bVal === 'string') {
      return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    }
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    }
    return 0;
  });

  const SortIcon = ({ field }: { field: keyof Receipt }) => {
    if (sortField !== field) return <ChevronDown size={14} className="text-slate-300 ml-1" />;
    return sortDirection === 'asc' ? <ChevronUp size={14} className="text-blue-500 ml-1" /> : <ChevronDown size={14} className="text-blue-500 ml-1" />;
  };

  const getPmtIcon = (mode: string) => {
    switch (mode) {
      case 'Cash': return <Banknote size={14} className="text-emerald-500" />;
      case 'Bank Transfer': return <Landmark size={14} className="text-blue-500" />;
      case 'Credit Card': return <CreditCard size={14} className="text-indigo-500" />;
      case 'Mobile Pay': return <Smartphone size={14} className="text-amber-500" />;
      default: return <FileText size={14} className="text-slate-500" />;
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-full">
      <div className="overflow-x-auto custom-scrollbar flex-grow">
        <table className="w-full text-left border-collapse min-w-[1300px]">
          <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 z-10">
            <tr>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer" onClick={() => handleSort('date')}>
                <div className="flex items-center">Trx Date <SortIcon field="date" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer" onClick={() => handleSort('id')}>
                <div className="flex items-center">Trx ID <SortIcon field="id" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Customer Info</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Location</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">SO ID</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Invoice Num</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">PMT Mode</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Amount Received</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sortedReceipts.map((trx) => (
              <tr key={trx.id} className="hover:bg-slate-50 transition-colors group">
                <td className="px-4 py-4 text-sm text-slate-500">{trx.date}</td>
                <td className="px-4 py-4 text-sm font-bold text-blue-600 font-mono">{trx.id}</td>
                <td className="px-4 py-4 text-sm">
                  <div className="font-semibold text-slate-800">{trx.customerName}</div>
                  <div className="text-[10px] text-slate-400 uppercase tracking-tighter">{trx.customerId}</div>
                </td>
                <td className="px-4 py-4 text-sm text-slate-500">
                  {trx.city}, {trx.state}
                </td>
                <td className="px-4 py-4 text-sm text-slate-600 font-semibold">{trx.soId}</td>
                <td className="px-4 py-4 text-sm text-slate-600 font-mono">{trx.invoiceNum}</td>
                <td className="px-4 py-4 text-sm text-slate-600">
                  <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-slate-50 border border-slate-100 w-max text-xs font-medium">
                    {getPmtIcon(trx.paymentMode)}
                    {trx.paymentMode}
                  </div>
                </td>
                <td className="px-4 py-4 text-sm text-right font-bold text-emerald-600">
                  ${trx.amountReceived.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </td>
                <td className="px-4 py-4 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => onEdit(trx)} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                      <Edit2 size={16} />
                    </button>
                    <button onClick={() => onDelete(trx.id)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
