
import React from 'react';
import { Sparkles, ArrowRight, Zap, Info } from 'lucide-react';
import { GeminiInsight } from '../types';

interface InsightsPanelProps {
  insights: GeminiInsight[];
  loading: boolean;
  onRefresh: () => void;
}

export const InsightsPanel: React.FC<InsightsPanelProps> = ({ insights, loading, onRefresh }) => {
  return (
    <div className="bg-gradient-to-br from-indigo-900 to-slate-900 rounded-2xl p-6 text-white shadow-xl mb-8 overflow-hidden relative">
      <div className="absolute top-0 right-0 p-12 opacity-10 rotate-12">
        <Sparkles size={120} />
      </div>

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-500 bg-opacity-30 p-2 rounded-lg backdrop-blur-sm">
              <Zap className="text-indigo-400" size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold">AI Business Intelligence</h2>
              <p className="text-indigo-300 text-xs">Real-time optimization insights by Gemini 3</p>
            </div>
          </div>
          <button 
            onClick={onRefresh}
            disabled={loading}
            className="px-4 py-2 bg-white bg-opacity-10 hover:bg-opacity-20 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 border border-white border-opacity-20 disabled:opacity-50"
          >
            {loading ? 'Analyzing...' : 'Refresh Insights'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {loading ? (
            Array(3).fill(0).map((_, i) => (
              <div key={i} className="animate-pulse bg-white bg-opacity-5 rounded-xl p-4 h-32"></div>
            ))
          ) : insights.length > 0 ? (
            insights.map((insight, idx) => (
              <div key={idx} className="bg-white bg-opacity-10 border border-white border-opacity-10 rounded-xl p-4 hover:bg-opacity-15 transition-all">
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded ${
                    insight.priority === 'high' ? 'bg-rose-500 text-white' : 
                    insight.priority === 'medium' ? 'bg-amber-500 text-white' : 'bg-slate-500 text-white'
                  }`}>
                    {insight.priority} Priority
                  </span>
                </div>
                <h4 className="font-bold mb-1 text-white">{insight.title}</h4>
                <p className="text-indigo-100 text-sm leading-relaxed opacity-80">{insight.description}</p>
              </div>
            ))
          ) : (
            <div className="col-span-3 text-center py-8 text-indigo-200 flex flex-col items-center">
               <Info size={40} className="mb-2 opacity-50" />
               <p>No insights generated yet. Click refresh to analyze your data.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
