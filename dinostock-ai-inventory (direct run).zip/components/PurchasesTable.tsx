
import React, { useState } from 'react';
import { Edit2, Trash2, ChevronDown, ChevronUp, Package, Truck, CheckCircle2, XCircle, Clock } from 'lucide-react';
import { Purchase } from '../types';

interface PurchasesTableProps {
  purchases: Purchase[];
  onEdit: (purchase: Purchase) => void;
  onDelete: (id: string) => void;
}

export const PurchasesTable: React.FC<PurchasesTableProps> = ({ purchases, onEdit, onDelete }) => {
  const [sortField, setSortField] = useState<keyof Purchase>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const handleSort = (field: keyof Purchase) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedPurchases = [...purchases].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];
    if (typeof aVal === 'string' && typeof bVal === 'string') {
      return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    }
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    }
    return 0;
  });

  const SortIcon = ({ field }: { field: keyof Purchase }) => {
    if (sortField !== field) return <ChevronDown size={14} className="text-slate-300 ml-1" />;
    return sortDirection === 'asc' ? <ChevronUp size={14} className="text-blue-500 ml-1" /> : <ChevronDown size={14} className="text-blue-500 ml-1" />;
  };

  const getPmtStatusBadge = (total: number, paid: number) => {
    const balance = total - paid;
    if (balance <= 0) return <span className="px-2 py-1 bg-emerald-100 text-emerald-700 rounded-full text-[10px] font-bold">PAID</span>;
    if (paid > 0) return <span className="px-2 py-1 bg-amber-100 text-amber-700 rounded-full text-[10px] font-bold">PARTIAL</span>;
    return <span className="px-2 py-1 bg-rose-100 text-rose-700 rounded-full text-[10px] font-bold">UNPAID</span>;
  };

  const getShippingIcon = (status: Purchase['shippingStatus']) => {
    switch (status) {
      case 'Delivered': return <CheckCircle2 size={14} className="text-emerald-500" />;
      case 'Shipped': return <Truck size={14} className="text-blue-500" />;
      case 'Pending': return <Clock size={14} className="text-amber-500" />;
      case 'Cancelled': return <XCircle size={14} className="text-rose-500" />;
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-full">
      <div className="overflow-x-auto custom-scrollbar flex-grow">
        <table className="w-full text-left border-collapse min-w-[1300px]">
          <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 z-10">
            <tr>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer" onClick={() => handleSort('date')}>
                <div className="flex items-center">Date <SortIcon field="date" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer" onClick={() => handleSort('id')}>
                <div className="flex items-center">PO ID <SortIcon field="id" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Supplier Info</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Bill Num</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Location</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Total Amount</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Total Paid</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">PO Balance</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-center">PMT Status</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-center">Shipping</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sortedPurchases.map((po) => {
              const balance = po.totalAmount - po.totalPaid;
              return (
                <tr key={po.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-4 py-4 text-sm text-slate-500">{po.date}</td>
                  <td className="px-4 py-4 text-sm font-bold text-blue-600">{po.id}</td>
                  <td className="px-4 py-4 text-sm">
                    <div className="font-semibold text-slate-800">{po.supplierName}</div>
                    <div className="text-[10px] text-slate-400 uppercase tracking-tighter">{po.supplierId}</div>
                  </td>
                  <td className="px-4 py-4 text-sm text-slate-600 font-mono">{po.billNum}</td>
                  <td className="px-4 py-4 text-sm text-slate-500">
                    {po.city}, {po.state}
                  </td>
                  <td className="px-4 py-4 text-sm text-right font-medium text-slate-900">
                    ${po.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-4 text-sm text-right text-emerald-600">
                    ${po.totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                  <td className={`px-4 py-4 text-sm text-right font-bold ${balance > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                    ${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-4 text-center">
                    {getPmtStatusBadge(po.totalAmount, po.totalPaid)}
                  </td>
                  <td className="px-4 py-4 text-center">
                    <div className="flex items-center justify-center gap-1.5 px-2 py-1 rounded-lg border border-slate-100 bg-white shadow-sm w-max mx-auto text-[10px] font-bold text-slate-600">
                      {getShippingIcon(po.shippingStatus)}
                      {po.shippingStatus.toUpperCase()}
                    </div>
                  </td>
                  <td className="px-4 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => onEdit(po)} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                        <Edit2 size={16} />
                      </button>
                      <button onClick={() => onDelete(po.id)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
