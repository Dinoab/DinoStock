
import React from 'react';
import { Package, AlertTriangle, ShoppingCart, TrendingUp } from 'lucide-react';
import { InventoryItem } from '../types';

interface StatsCardsProps {
  items: InventoryItem[];
}

export const StatsCards: React.FC<StatsCardsProps> = ({ items }) => {
  const totalPurchased = items.reduce((acc, item) => acc + item.qtyPurchased, 0);
  const totalSold = items.reduce((acc, item) => acc + item.qtySold, 0);
  const lowStock = items.filter(i => (i.qtyPurchased - i.qtySold) <= i.reorderLevel).length;
  const outOfStock = items.filter(i => (i.qtyPurchased - i.qtySold) <= 0).length;

  const stats = [
    { 
      label: 'Total Items', 
      value: items.length, 
      icon: Package, 
      color: 'bg-blue-500', 
      textColor: 'text-blue-600' 
    },
    { 
      label: 'Low Stock Alerts', 
      value: lowStock, 
      icon: AlertTriangle, 
      color: 'bg-amber-500', 
      textColor: 'text-amber-600' 
    },
    { 
      label: 'Items Sold', 
      value: totalSold, 
      icon: TrendingUp, 
      color: 'bg-emerald-500', 
      textColor: 'text-emerald-600' 
    },
    { 
      label: 'Out of Stock', 
      value: outOfStock, 
      icon: ShoppingCart, 
      color: 'bg-rose-500', 
      textColor: 'text-rose-600' 
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, idx) => (
        <div key={idx} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className={`p-2 rounded-lg ${stat.color} bg-opacity-10 ${stat.textColor}`}>
              <stat.icon size={24} />
            </div>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">{stat.label}</h3>
          <p className="text-2xl font-bold text-slate-800 mt-1">{stat.value.toLocaleString()}</p>
        </div>
      ))}
    </div>
  );
};
