
import { GoogleGenAI, Type } from "@google/genai";
import { InventoryItem } from "../types";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getInventoryInsights = async (items: InventoryItem[]) => {
  try {
    const prompt = `
      Analyze the following inventory data and provide 3 actionable business insights or optimization suggestions.
      Current Inventory: ${JSON.stringify(items)}
      Focus on stock replenishment, sales trends, and potential risks.
    `;

    // Use ai.models.generateContent to query GenAI with both the model name and prompt.
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              priority: { type: Type.STRING },
            },
            required: ['title', 'description', 'priority'],
          },
        },
      },
    });

    // Extracting text from the response using the .text property
    return JSON.parse(response.text || '[]');
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return [];
  }
};
