import { InventoryItem, Supplier, Customer, Purchase, Sale, Receipt, Payment, User } from '../types';

/**
 * DinoStock AI - Local Server API Connector
 * Connects to api.php for MySQL persistence.
 */

const API_URL = 'api.php';

const fetchEntity = async <T>(entity: string): Promise<T[]> => {
  try {
    const response = await fetch(`${API_URL}?entity=${entity}`);
    if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
    return await response.json();
  } catch (err) {
    console.error(`Failed to fetch ${entity}:`, err);
    return [];
  }
};

const saveEntity = async <T>(entity: string, data: T[]): Promise<void> => {
  try {
    await fetch(`${API_URL}?entity=${entity}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
  } catch (err) {
    console.error(`Failed to save ${entity}:`, err);
  }
};

export const apiService = {
  // Inventory
  getItems: async (): Promise<InventoryItem[]> => fetchEntity('items'),
  saveItems: async (items: InventoryItem[]) => saveEntity('items', items),

  // Suppliers
  getSuppliers: async (): Promise<Supplier[]> => fetchEntity('suppliers'),
  saveSuppliers: async (suppliers: Supplier[]) => saveEntity('suppliers', suppliers),

  // Customers
  getCustomers: async (): Promise<Customer[]> => fetchEntity('customers'),
  saveCustomers: async (customers: Customer[]) => saveEntity('customers', customers),

  // Purchases
  getPurchases: async (): Promise<Purchase[]> => fetchEntity('purchases'),
  savePurchases: async (purchases: Purchase[]) => saveEntity('purchases', purchases),

  // Sales
  getSales: async (): Promise<Sale[]> => fetchEntity('sales'),
  saveSales: async (sales: Sale[]) => saveEntity('sales', sales),

  // Receipts
  getReceipts: async (): Promise<Receipt[]> => fetchEntity('receipts'),
  saveReceipts: async (receipts: Receipt[]) => saveEntity('receipts', receipts),

  // Payments
  getPayments: async (): Promise<Payment[]> => fetchEntity('payments'),
  savePayments: async (payments: Payment[]) => saveEntity('payments', payments),

  // Users
  getUsers: async (): Promise<User[]> => fetchEntity('users'),
  saveUsers: async (users: User[]) => saveEntity('users', users),
};