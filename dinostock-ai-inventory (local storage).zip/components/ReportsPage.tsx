
import React, { useMemo, useState } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Package, 
  ArrowRight, 
  Calendar, 
  Download, 
  Box, 
  Printer, 
  Filter,
  BarChart3,
  AlertTriangle,
  Layers,
  ChevronDown,
  Archive,
  ShoppingCart,
  Truck,
  Receipt
} from 'lucide-react';
import { Sale, Purchase, InventoryItem, Receipt as ReceiptType, Payment } from '../types';

interface ReportsPageProps {
  sales: Sale[];
  purchases: Purchase[];
  inventory: InventoryItem[];
  receipts: ReceiptType[];
  payments: Payment[];
}

type ReportType = 'most-available' | 'top-selling' | 'stock-balance' | 'low-critical' | 'best-category' | 'purchased-products' | 'sold-products';

export const ReportsPage: React.FC<ReportsPageProps> = ({ sales, purchases, inventory, receipts, payments }) => {
  const [reportType, setReportType] = useState<ReportType>('most-available');
  const [startDate, setStartDate] = useState<string>('2024-01-01');
  const [endDate, setEndDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // Financial Calculations
  const metrics = useMemo(() => {
    const totalRevenue = sales.reduce((sum, s) => sum + s.totalAmount, 0);
    const totalProcurement = purchases.reduce((sum, p) => sum + p.totalAmount, 0);
    const totalCashIn = receipts.reduce((sum, r) => sum + r.amountReceived, 0);
    const totalCashOut = payments.reduce((sum, p) => sum + p.amountPaid, 0);
    const netCashFlow = totalCashIn - totalCashOut;
    
    const inventoryValuation = inventory.reduce((sum, item) => {
      const remaining = item.qtyPurchased - item.qtySold;
      return sum + (remaining * 100); 
    }, 0);

    return {
      totalRevenue,
      totalProcurement,
      totalCashIn,
      totalCashOut,
      netCashFlow,
      inventoryValuation,
    };
  }, [sales, purchases, inventory, receipts, payments]);

  // Dynamic Report Data Generation
  const reportData = useMemo(() => {
    switch (reportType) {
      case 'most-available':
        return [...inventory]
          .sort((a, b) => (b.qtyPurchased - b.qtySold) - (a.qtyPurchased - a.qtySold));
      
      case 'top-selling':
        return [...inventory]
          .sort((a, b) => b.qtySold - a.qtySold);
      
      case 'stock-balance':
        return [...inventory];
      
      case 'low-critical':
        return inventory.filter(item => (item.qtyPurchased - item.qtySold) <= item.reorderLevel);
      
      case 'best-category':
        const categories = Array.from(new Set(inventory.map(i => i.category)));
        return categories.map(cat => {
          const catItems = inventory.filter(i => i.category === cat);
          const totalSold = catItems.reduce((sum, i) => sum + i.qtySold, 0);
          const totalRevenue = totalSold * 150; // Mock average price
          return { category: cat, unitsSold: totalSold, revenue: totalRevenue, itemCount: catItems.length };
        }).sort((a, b) => b.revenue - a.revenue);

      case 'purchased-products':
        return purchases
          .filter(p => p.date >= startDate && p.date <= endDate)
          .sort((a, b) => b.date.localeCompare(a.date));

      case 'sold-products':
        return sales
          .filter(s => s.date >= startDate && s.date <= endDate)
          .sort((a, b) => b.date.localeCompare(a.date));
      
      default:
        return [];
    }
  }, [reportType, inventory, purchases, sales, startDate, endDate]);

  const handlePrint = () => {
    window.print();
  };

  const getReportTitle = () => {
    switch(reportType) {
      case 'most-available': return 'Most Available Products Report';
      case 'top-selling': return 'Top Selling Products Report';
      case 'stock-balance': return 'Full Stock Balance Report';
      case 'low-critical': return 'Critical Low Stock Alert Report';
      case 'best-category': return 'Best Performing Categories Report';
      case 'purchased-products': return 'Purchased Products (Procurement Log)';
      case 'sold-products': return 'Sold Products (Sales Log)';
      default: return 'Business Report';
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      {/* Print-Only Header */}
      <div className="print-only mb-8 border-b-2 border-slate-900 pb-4">
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">DinoStock AI Business Intelligence</h1>
            <p className="text-slate-500 font-medium uppercase tracking-widest text-xs mt-1">{getReportTitle()}</p>
          </div>
          <div className="text-right">
            <p className="text-sm font-bold text-slate-800">Date Range: {startDate} to {endDate}</p>
            <p className="text-[10px] text-slate-500 mt-1">Generated: {new Date().toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Interactive Controls Header */}
      <div className="no-print flex flex-col md:flex-row items-center justify-between bg-white p-6 rounded-2xl border border-slate-200 shadow-sm gap-6">
        <div className="flex flex-wrap items-center gap-4 w-full md:w-auto">
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Select Report Type</label>
            <div className="relative">
              <select 
                value={reportType} 
                onChange={(e) => setReportType(e.target.value as ReportType)}
                className="appearance-none bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 pr-10 text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 min-w-[240px]"
              >
                <option value="most-available">Most Available Products</option>
                <option value="top-selling">Top Selling Products</option>
                <option value="stock-balance">Full Stock Balance</option>
                <option value="low-critical">Low Critical Products</option>
                <option value="best-category">Best Performing Categories</option>
                <option value="purchased-products">Purchased Products Log</option>
                <option value="sold-products">Sold Products Log</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Date Range</label>
            <div className="flex items-center gap-2">
              <input 
                type="date" 
                value={startDate} 
                onChange={(e) => setStartDate(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500" 
              />
              <span className="text-slate-400 font-bold">to</span>
              <input 
                type="date" 
                value={endDate} 
                onChange={(e) => setEndDate(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500" 
              />
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <button 
            onClick={handlePrint}
            className="flex-grow md:flex-initial flex items-center justify-center gap-2 px-6 py-3 bg-slate-900 text-white rounded-xl text-sm font-bold hover:bg-slate-800 transition-all shadow-lg shadow-slate-200 active:scale-95"
          >
            <Printer size={18} /> Print Report
          </button>
          <button className="p-3 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-all shadow-sm">
            <Download size={18} />
          </button>
        </div>
      </div>

      {/* Summary Tiles */}
      <div className="no-print grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <ReportKPICard 
          title="Revenue (Period)" 
          value={`$${metrics.totalRevenue.toLocaleString()}`} 
          trend="+12%" 
          isPositive={true} 
          icon={<TrendingUp size={20} />}
          color="blue"
        />
        <ReportKPICard 
          title="Inventory Assets" 
          value={`$${metrics.inventoryValuation.toLocaleString()}`} 
          trend="+4.8%" 
          isPositive={true} 
          icon={<Package size={20} />}
          color="amber"
        />
        <ReportKPICard 
          title="Cash Balance" 
          value={`$${metrics.netCashFlow.toLocaleString()}`} 
          trend="-2.1%" 
          isPositive={metrics.netCashFlow > 0} 
          icon={<DollarSign size={20} />}
          color="emerald"
        />
        <ReportKPICard 
          title="Critical Alerts" 
          value={inventory.filter(i => (i.qtyPurchased - i.qtySold) <= i.reorderLevel).length.toString()} 
          trend="Action Req" 
          isPositive={false} 
          icon={<AlertTriangle size={20} />}
          color="rose"
        />
      </div>

      {/* Dynamic Data Table Area */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50 no-print">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-200">
              {reportType === 'most-available' && <Archive size={20} />}
              {reportType === 'top-selling' && <TrendingUp size={20} />}
              {reportType === 'stock-balance' && <BarChart3 size={20} />}
              {reportType === 'low-critical' && <AlertTriangle size={20} />}
              {reportType === 'best-category' && <Layers size={20} />}
              {reportType === 'purchased-products' && <Truck size={20} />}
              {reportType === 'sold-products' && <ShoppingCart size={20} />}
            </div>
            <div>
              <h3 className="font-bold text-lg text-slate-800 uppercase tracking-tight">{getReportTitle()}</h3>
              <p className="text-slate-500 text-xs">Analysis based on system data from {startDate} to {endDate}</p>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs bg-emerald-100 text-emerald-700 px-3 py-1.5 rounded-full font-black uppercase tracking-widest border border-emerald-200">Verified System Data</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          {reportType === 'best-category' ? (
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-[10px] uppercase tracking-widest font-black text-slate-400 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4">Category Name</th>
                  <th className="px-6 py-4 text-center">Item Count</th>
                  <th className="px-6 py-4 text-center">Total Units Sold</th>
                  <th className="px-6 py-4 text-right">Est. Revenue Contribution</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(reportData as any[]).map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-6 py-4 font-bold text-slate-800">{row.category}</td>
                    <td className="px-6 py-4 text-center text-slate-600 font-medium">{row.itemCount}</td>
                    <td className="px-6 py-4 text-center text-slate-600 font-medium">{row.unitsSold}</td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex flex-col items-end">
                        <span className="text-sm font-black text-slate-900">${row.revenue.toLocaleString()}</span>
                        <div className="w-24 h-1.5 bg-slate-100 rounded-full mt-1.5 overflow-hidden">
                          <div className="h-full bg-blue-500" style={{ width: `${Math.min(100, (row.revenue / (metrics.totalRevenue || 1)) * 100)}%` }}></div>
                        </div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (reportType === 'purchased-products' || reportType === 'sold-products') ? (
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-[10px] uppercase tracking-widest font-black text-slate-400 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4">Transaction Date</th>
                  <th className="px-6 py-4">Order ID</th>
                  <th className="px-6 py-4">{reportType === 'purchased-products' ? 'Supplier' : 'Customer'}</th>
                  <th className="px-6 py-4">Ref Number</th>
                  <th className="px-6 py-4 text-right">Total Amount</th>
                  <th className="px-6 py-4 text-center">Shipping Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(reportData as (Purchase | Sale)[]).map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-6 py-4 text-sm text-slate-600">{row.date}</td>
                    <td className="px-6 py-4 text-sm font-black text-blue-600 font-mono">{row.id}</td>
                    <td className="px-6 py-4 text-sm font-bold text-slate-800">
                      {'supplierName' in row ? row.supplierName : row.customerName}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500 font-mono">
                      {'billNum' in row ? row.billNum : row.invoiceNum}
                    </td>
                    <td className="px-6 py-4 text-right font-black text-slate-900">
                      ${row.totalAmount.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        row.shippingStatus === 'Delivered' ? 'bg-emerald-100 text-emerald-700' :
                        row.shippingStatus === 'Shipped' ? 'bg-blue-100 text-blue-700' :
                        row.shippingStatus === 'Pending' ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'
                      }`}>
                        {row.shippingStatus}
                      </span>
                    </td>
                  </tr>
                ))}
                {reportData.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-slate-400 italic">
                      No records found for the selected date range.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-[10px] uppercase tracking-widest font-black text-slate-400 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4">Item Identification</th>
                  <th className="px-4 py-4">Category</th>
                  <th className="px-4 py-4 text-center">Purchased</th>
                  <th className="px-4 py-4 text-center">Sold</th>
                  <th className="px-4 py-4 text-center">Remaining</th>
                  {reportType === 'low-critical' && <th className="px-4 py-4 text-center">Reorder Level</th>}
                  <th className="px-6 py-4 text-right">Status Matrix</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(reportData as InventoryItem[]).map((item, idx) => {
                  const remaining = item.qtyPurchased - item.qtySold;
                  const isLow = remaining <= item.reorderLevel;
                  
                  return (
                    <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-6 py-4">
                        <div className="font-bold text-slate-900 text-sm">{item.name}</div>
                        <div className="text-[10px] font-mono text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded w-max mt-1">{item.id}</div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="text-xs font-bold text-slate-700">{item.category}</span>
                      </td>
                      <td className="px-4 py-4 text-center text-slate-600 font-medium">{item.qtyPurchased}</td>
                      <td className="px-4 py-4 text-center text-slate-600 font-medium">{item.qtySold}</td>
                      <td className="px-4 py-4 text-center">
                        <span className={`text-sm font-black ${remaining <= 0 ? 'text-rose-600' : isLow ? 'text-amber-600' : 'text-slate-900'}`}>
                          {remaining}
                        </span>
                      </td>
                      {reportType === 'low-critical' && <td className="px-4 py-4 text-center font-bold text-slate-400">{item.reorderLevel}</td>}
                      <td className="px-6 py-4 text-right">
                        <div className="flex flex-col items-end gap-1">
                          {reportType === 'top-selling' ? (
                            <span className="text-[9px] font-bold text-emerald-600 uppercase bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">High Velocity</span>
                          ) : isLow ? (
                            <span className="text-[9px] font-bold text-rose-600 uppercase bg-rose-50 px-2 py-0.5 rounded border border-rose-100">Critical Low</span>
                          ) : (
                            <span className="text-[9px] font-bold text-blue-600 uppercase bg-blue-50 px-2 py-0.5 rounded border border-blue-100">Stable</span>
                          )}
                          <div className="w-20 h-1 bg-slate-100 rounded-full mt-1 overflow-hidden">
                             <div 
                                className={`h-full ${isLow ? 'bg-rose-500' : 'bg-blue-500'}`} 
                                style={{ width: `${Math.min(100, (remaining / (item.qtyPurchased || 1)) * 100)}%` }}
                             ></div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Print Footer */}
      <div className="print-only mt-12 pt-8 border-t border-slate-200 flex justify-between items-center text-slate-400 text-[10px] uppercase font-bold tracking-widest">
        <span>&copy; 2024 DinoStock AI Inventory Systems</span>
        <span>Secure Document | Ref: {reportType.toUpperCase()}-{new Date().getTime()}</span>
        <span>Unauthorized distribution is prohibited.</span>
      </div>
    </div>
  );
};

const ReportKPICard = ({ title, value, trend, isPositive, icon, color }: { 
  title: string; 
  value: string; 
  trend: string; 
  isPositive: boolean; 
  icon: React.ReactNode;
  color: 'blue' | 'amber' | 'emerald' | 'rose';
}) => {
  const colorMap = {
    blue: 'bg-blue-500 text-blue-600 border-blue-100',
    amber: 'bg-amber-500 text-amber-600 border-amber-100',
    emerald: 'bg-emerald-500 text-emerald-600 border-emerald-100',
    rose: 'bg-rose-500 text-rose-600 border-rose-100'
  };

  return (
    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all group">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-2 rounded-xl bg-opacity-10 ${colorMap[color].split(' ')[1]} ${colorMap[color].split(' ')[0]}`}>
          {icon}
        </div>
        <span className={`text-[10px] font-black ${isPositive ? 'text-emerald-600' : 'text-rose-600'} bg-opacity-10 px-2.5 py-1 rounded-full flex items-center gap-1 border border-current border-opacity-20`}>
          {trend}
        </span>
      </div>
      <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-widest">{title}</h3>
      <p className="text-2xl font-black text-slate-800 mt-1 tracking-tight">{value}</p>
    </div>
  );
};
