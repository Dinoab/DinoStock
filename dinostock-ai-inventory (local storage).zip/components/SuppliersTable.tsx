
import React, { useState } from 'react';
import { Edit2, Trash2, ChevronDown, ChevronUp, Mail, Phone, MapPin } from 'lucide-react';
import { Supplier } from '../types';

interface SuppliersTableProps {
  suppliers: Supplier[];
  onEdit: (supplier: Supplier) => void;
  onDelete: (id: string) => void;
}

export const SuppliersTable: React.FC<SuppliersTableProps> = ({ suppliers, onEdit, onDelete }) => {
  const [sortField, setSortField] = useState<keyof Supplier>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const handleSort = (field: keyof Supplier) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedSuppliers = [...suppliers].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];
    if (typeof aVal === 'string' && typeof bVal === 'string') {
      return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    }
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    }
    return 0;
  });

  const SortIcon = ({ field }: { field: keyof Supplier }) => {
    if (sortField !== field) return <ChevronDown size={14} className="text-slate-300 ml-1" />;
    return sortDirection === 'asc' ? <ChevronUp size={14} className="text-blue-500 ml-1" /> : <ChevronDown size={14} className="text-blue-500 ml-1" />;
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-full">
      <div className="overflow-x-auto custom-scrollbar flex-grow">
        <table className="w-full text-left border-collapse min-w-[1200px]">
          <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 z-10">
            <tr>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('id')}>
                <div className="flex items-center">Supplier ID <SortIcon field="id" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('name')}>
                <div className="flex items-center">Supplier Name <SortIcon field="name" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Contact Info</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Location</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Purchases ($)</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Payments ($)</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Balance ($)</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sortedSuppliers.map((supplier) => {
              const balance = supplier.purchases - supplier.payments;

              return (
                <tr key={supplier.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-4 py-4 text-sm font-medium text-blue-600">{supplier.id}</td>
                  <td className="px-4 py-4 text-sm font-bold text-slate-800">{supplier.name}</td>
                  <td className="px-4 py-4 text-sm text-slate-600">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1 text-slate-500"><Phone size={12}/> {supplier.contact}</div>
                      <div className="flex items-center gap-1 text-blue-500"><Mail size={12}/> {supplier.email}</div>
                    </div>
                  </td>
                  <td className="px-4 py-4 text-sm text-slate-600">
                    <div className="flex items-center gap-1 text-slate-500"><MapPin size={12}/> {supplier.city}, {supplier.state}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{supplier.address}</div>
                  </td>
                  <td className="px-4 py-4 text-sm text-slate-600 text-right font-medium">
                    {supplier.purchases.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-4 text-sm text-emerald-600 text-right font-medium">
                    {supplier.payments.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                  <td className={`px-4 py-4 text-sm text-right font-bold ${balance > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                    {balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => onEdit(supplier)}
                        className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Edit Supplier"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => onDelete(supplier.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete Supplier"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
