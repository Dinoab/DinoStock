
import React from 'react';
import { FileText, CreditCard, Clock, CheckSquare } from 'lucide-react';
import { Purchase } from '../types';

interface PurchaseStatsProps {
  purchases: Purchase[];
}

export const PurchaseStats: React.FC<PurchaseStatsProps> = ({ purchases }) => {
  const totalAmount = purchases.reduce((acc, p) => acc + p.totalAmount, 0);
  const totalPaid = purchases.reduce((acc, p) => acc + p.totalPaid, 0);
  const outstanding = totalAmount - totalPaid;
  const pendingShipments = purchases.filter(p => p.shippingStatus !== 'Delivered' && p.shippingStatus !== 'Cancelled').length;

  const stats = [
    { 
      label: 'Total POs', 
      value: purchases.length, 
      icon: FileText, 
      color: 'bg-blue-500', 
      textColor: 'text-blue-600' 
    },
    { 
      label: 'Total Procurement', 
      value: `$${totalAmount.toLocaleString()}`, 
      icon: CreditCard, 
      color: 'bg-indigo-500', 
      textColor: 'text-indigo-600' 
    },
    { 
      label: 'Accounts Payable', 
      value: `$${outstanding.toLocaleString()}`, 
      icon: Clock, 
      color: 'bg-rose-500', 
      textColor: 'text-rose-600' 
    },
    { 
      label: 'Active Shipments', 
      value: pendingShipments, 
      icon: CheckSquare, 
      color: 'bg-emerald-500', 
      textColor: 'text-emerald-600' 
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, idx) => (
        <div key={idx} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className={`p-2 rounded-lg ${stat.color} bg-opacity-10 ${stat.textColor}`}>
              <stat.icon size={24} />
            </div>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">{stat.label}</h3>
          <p className="text-2xl font-bold text-slate-800 mt-1">{stat.value}</p>
        </div>
      ))}
    </div>
  );
};
