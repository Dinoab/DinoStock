
import React, { useState } from 'react';
import { Edit2, Trash2, ChevronDown, ChevronUp, Mail, Shield, ShieldCheck, User as UserIcon, Clock } from 'lucide-react';
import { User } from '../types';

interface UsersTableProps {
  users: User[];
  onEdit: (user: User) => void;
  onDelete: (id: string) => void;
}

export const UsersTable: React.FC<UsersTableProps> = ({ users, onEdit, onDelete }) => {
  const [sortField, setSortField] = useState<keyof User>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const handleSort = (field: keyof User) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedUsers = [...users].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];
    if (typeof aVal === 'string' && typeof bVal === 'string') {
      return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    }
    return 0;
  });

  const SortIcon = ({ field }: { field: keyof User }) => {
    if (sortField !== field) return <ChevronDown size={14} className="text-slate-300 ml-1" />;
    return sortDirection === 'asc' ? <ChevronUp size={14} className="text-blue-500 ml-1" /> : <ChevronDown size={14} className="text-blue-500 ml-1" />;
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'Admin':
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-100 text-rose-700 text-xs font-bold ring-1 ring-rose-200">
            <Shield size={12} /> {role}
          </span>
        );
      case 'Manager':
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-100 text-indigo-700 text-xs font-bold ring-1 ring-indigo-200">
            <ShieldCheck size={12} /> {role}
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold ring-1 ring-slate-200">
            <UserIcon size={12} /> {role}
          </span>
        );
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-full">
      <div className="overflow-x-auto custom-scrollbar flex-grow">
        <table className="w-full text-left border-collapse min-w-[1000px]">
          <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 z-10">
            <tr>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('id')}>
                <div className="flex items-center">User ID <SortIcon field="id" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('name')}>
                <div className="flex items-center">Name <SortIcon field="name" /></div>
              </th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Email</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Role</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Status</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm">Last Login</th>
              <th className="px-4 py-4 font-semibold text-slate-600 text-sm text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sortedUsers.map((user) => (
              <tr key={user.id} className="hover:bg-slate-50 transition-colors group">
                <td className="px-4 py-4 text-sm font-medium text-blue-600 font-mono">{user.id}</td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-bold text-xs uppercase">
                      {user.name.charAt(0)}
                    </div>
                    <div className="font-semibold text-slate-800">{user.name}</div>
                  </div>
                </td>
                <td className="px-4 py-4 text-sm text-slate-600">
                  <div className="flex items-center gap-1.5 hover:text-blue-600 transition-colors cursor-pointer">
                    <Mail size={14} className="text-slate-400" />
                    {user.email}
                  </div>
                </td>
                <td className="px-4 py-4">
                  {getRoleBadge(user.role)}
                </td>
                <td className="px-4 py-4">
                  <span className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest ${
                    user.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {user.status}
                  </span>
                </td>
                <td className="px-4 py-4 text-sm text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <Clock size={14} className="text-slate-400" />
                    {user.lastLogin}
                  </div>
                </td>
                <td className="px-4 py-4 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={() => onEdit(user)}
                      className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      title="Edit User"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button 
                      onClick={() => onDelete(user.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      title="Delete User"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
